class Client < ApplicationRecord
  self.table_name = "client"
end
