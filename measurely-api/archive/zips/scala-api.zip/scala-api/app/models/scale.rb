class Scale < ApplicationRecord
end
