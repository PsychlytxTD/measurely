# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation
rake db:create
rake db:migrate
rake db:seed

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)
rails s

* Deployment instructions

* Creating a controller:
KEEP THIS FUCKING SKINNY
FAT MODELS, SKINNY CONTROLLERS
rails g scaffold_controller Client
