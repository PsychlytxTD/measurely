module ScaleHelper
end
