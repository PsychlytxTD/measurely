class Clinician < ApplicationRecord
end
