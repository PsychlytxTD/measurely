class AnalyticsPosttherapy < ApplicationRecord
end
